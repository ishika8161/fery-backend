const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const PORT = 3000;

app.use(bodyParser.json());


const ridesData = require('./data/rides.json');


app.post('/register', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required' });
  }
  res.status(201).json({ message: `User ${username} registered successfully!` });
});


app.get('/rides', (req, res) => {
  res.status(200).json(ridesData);
});


app.get('/rides/:id', (req, res) => {
  const rideId = req.params.id;
  const ride = ridesData.find(r => r.id === parseInt(rideId));
  if (!ride) {
    return res.status(404).json({ message: 'Ride not found' });
  }
  res.status(200).json(ride);
});


app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});

